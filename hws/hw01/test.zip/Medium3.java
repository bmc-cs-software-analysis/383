public class Medium3 {
    
    public int addOne(int c) {
        return c + 1; 
    }

    public void baz() {
        int x = addOne(0);
    }
}
