public class Example {
    public int add(int a, int b) {
        return a + b;
    }
    
    public int calculate() {
        return add(2, 3);
    }
}
