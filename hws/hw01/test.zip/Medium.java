public class Medium {
    
    public void myPrint(int c) {
        int d = c; 
    }

    public void baz() {
        myPrint(100);
    }
}
