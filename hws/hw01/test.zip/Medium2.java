public class Medium2 {
    
    public int one() {
        return 1;
    }

    public void foo() {
        one();
    }
}
