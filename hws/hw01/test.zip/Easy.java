public class Easy {

    public void foo() {
        System.out.println("Hello World!");
    }


    public void bar() {
        foo();
    }

}
