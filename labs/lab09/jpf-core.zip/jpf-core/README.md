                          Java PathFinder README
                          ======================

========General Information about JPF ===================

All the latest developments, changes, documentation can
be found at: 

https://github.com/javapathfinder/jpf-core/wiki

========Building and Installing =========================

If you are having problems installing and running JPF
please look at the documentation on the wiki at:

https://github.com/javapathfinder/jpf-core/wiki/How-to-install-JPF

A lot of the commonly problems during the install and build
process have been documented on the wiki. Please make sure
that the the issue you are running into is not addressed
there; if is not then feel free to contact us at
java-pathfinder@googlegroups.com


======Documentation======================================

There is a constant effort to update and add JPF
documentation on the wiki. If you would like to contribute
in that, please contact us at
java-pathfinder@googlegroups.com



Happy Verification
-- the Java PathFinder team
